```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve

df = pd.read_csv('framingham.csv')

print("\nDataset Shape:", df.shape)
print("Missing values per variable:\n", df.isnull().sum())
```

    
    Dataset Shape: (4240, 16)
    Missing values per variable:
     male                 0
    age                  0
    education          105
    currentSmoker        0
    cigsPerDay          29
    BPMeds              53
    prevalentStroke      0
    prevalentHyp         0
    diabetes             0
    totChol             50
    sysBP                0
    diaBP                0
    BMI                 19
    heartRate            1
    glucose            388
    TenYearCHD           0
    dtype: int64
    


```python
from sklearn.experimental import enable_iterative_imputer 
from sklearn.impute import IterativeImputer

impute_features = ['age', 'male', 'cigsPerDay', 'totChol', 'sysBP', 'diaBP',
                   'BMI', 'heartRate', 'glucose', 'TenYearCHD']
df_to_impute = df[impute_features].copy()

# Initialize the MICE Imputer
mice_imputer = IterativeImputer(random_state=42, max_iter=10)


df_imputed_array = mice_imputer.fit_transform(df_to_impute)

df_clean = pd.DataFrame(df_imputed_array, columns=impute_features)

print("Missing values after MICE Imputation:\n", df_clean.isnull().sum())
print(f"Total clinical sample size preserved: {len(df_clean)}") 

```

    Missing values after MICE Imputation:
     age           0
    male          0
    cigsPerDay    0
    totChol       0
    sysBP         0
    diaBP         0
    BMI           0
    heartRate     0
    glucose       0
    TenYearCHD    0
    dtype: int64
    Total clinical sample size preserved: 4240
    


```python
sns.set_theme(style="whitegrid")

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Plot 1: Age distribution by heart disease outcome
sns.boxplot(data=df_clean, x='TenYearCHD', y='age', hue='TenYearCHD',
            palette='Set2', legend=False, ax=axes[0])
axes[0].set_title('Age Distribution vs. 10-Year Heart Disease Risk')
axes[0].set_xticks([0, 1])
axes[0].set_xticklabels(['No Risk', 'At Risk'])

# Plot 2: Correlation heatmap
features_to_check = ['age', 'totChol', 'sysBP', 'diaBP', 'BMI', 'heartRate', 'glucose', 'TenYearCHD']
corr_matrix = df_clean[features_to_check].corr()
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f", ax=axes[1])
axes[1].set_title('Correlation Matrix of Key Metrics')

plt.tight_layout()
plt.show() 

```


    
![png](output_2_0.png)
    



```python
# TenYearCHD: 1 = Patient developed coronary heart disease in 10 years, 0 = Did not
X = df_clean[['age', 'male', 'cigsPerDay', 'totChol', 'sysBP', 'BMI', 'glucose']]
y = df_clean['TenYearCHD']

X_stat = sm.add_constant(X)

# Fit the Logistic Regression Model
stat_model = sm.Logit(y, X_stat).fit()

print(stat_model.summary())
```

    Optimization terminated successfully.
             Current function value: 0.379693
             Iterations 7
                               Logit Regression Results                           
    ==============================================================================
    Dep. Variable:             TenYearCHD   No. Observations:                 4240
    Model:                          Logit   Df Residuals:                     4232
    Method:                           MLE   Df Model:                            7
    Date:                Wed, 11 Nov 2026   Pseudo R-squ.:                  0.1086
    Time:                        14:36:22   Log-Likelihood:                -1609.9
    converged:                       True   LL-Null:                       -1806.1
    Covariance Type:            nonrobust   LLR p-value:                 1.009e-80
    ==============================================================================
                     coef    std err          z      P>|z|      [0.025      0.975]
    ------------------------------------------------------------------------------
    const         -8.9357      0.488    -18.316      0.000      -9.892      -7.979
    age            0.0642      0.006     10.749      0.000       0.052       0.076
    male           0.5040      0.098      5.119      0.000       0.311       0.697
    cigsPerDay     0.0213      0.004      5.493      0.000       0.014       0.029
    totChol        0.0017      0.001      1.668      0.095      -0.000       0.004
    sysBP          0.0165      0.002      7.901      0.000       0.012       0.021
    BMI            0.0055      0.011      0.483      0.629      -0.017       0.028
    glucose        0.0078      0.002      4.745      0.000       0.005       0.011
    ==============================================================================
    


```python
# Convert coefficients to Odds Ratios (OR)
odds_ratios = np.exp(stat_model.params)
conf_int = np.exp(stat_model.conf_int())
conf_int['Odds Ratio'] = odds_ratios

print("Odds Ratios and 95% Confidence Intervals:\n")
print(conf_int[['Odds Ratio', 0, 1]].rename(columns={0: 'Lower 95%', 1: 'Upper 95%'})) 
```

    Odds Ratios and 95% Confidence Intervals:
    
                Odds Ratio  Lower 95%  Upper 95%
    const         0.000132   0.000051   0.000342
    age           1.066270   1.053868   1.078819
    male          1.655302   1.364812   2.007619
    cigsPerDay    1.021489   1.013769   1.029268
    totChol       1.001712   0.999701   1.003727
    sysBP         1.016674   1.012512   1.020854
    BMI           1.005505   0.983344   1.028165
    glucose       1.007817   1.004581   1.011064
    


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy.stats import norm
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer

OUTCOME = "TenYearCHD"

# label and divisor for each predictor, so ORs are per clinically meaningful increment
UNITS = {
    "age":        ("per 10 years",         10),
    "male":       ("male vs female",        1),
    "cigsPerDay": ("per 10 cigarettes/day", 10),
    "totChol":    ("per 10 mg/dL",          10),
    "sysBP":      ("per 10 mmHg",           10),
    "BMI":        ("per 5 kg/m2",            5),
    "glucose":    ("per 10 mg/dL",          10),
}

def to_units(d):
    d = d[FEATURES].astype(float).copy()
    for col, (_, k) in UNITS.items():
        d[col] = d[col] / k
    return d

def fit_logit(d):
    X = sm.add_constant(to_units(d))
    return sm.Logit(d[OUTCOME].astype(float), X).fit(disp=0)

def or_ci(params, se):
    return np.exp(params), np.exp(params - 1.96 * se), np.exp(params + 1.96 * se)

# 1) Complete-case analysis: only rows with no missing predictor
cc = df[FEATURES + [OUTCOME]].dropna()
m_cc = fit_logit(cc)

# 2) Your existing single-imputation data (df_clean)
m_si = fit_logit(df_clean)

# 3) Multiple imputation: 20 imputed datasets, results pooled with Rubin's rules
M = 20
params_list, var_list = [], []
for i in range(M):
    imp = IterativeImputer(sample_posterior=True, random_state=i, max_iter=10, min_value=0)
    arr = imp.fit_transform(df[FEATURES + [OUTCOME]])
    d_i = pd.DataFrame(arr, columns=FEATURES + [OUTCOME])
    r = fit_logit(d_i)
    params_list.append(r.params)
    var_list.append(r.bse ** 2)

P = pd.concat(params_list, axis=1)
V = pd.concat(var_list, axis=1)
q_bar = P.mean(axis=1)
u_bar = V.mean(axis=1)
b = P.var(axis=1, ddof=1)
se_mi = np.sqrt(u_bar + (1 + 1 / M) * b)            # Rubin's total variance
p_mi = pd.Series(2 * (1 - norm.cdf(np.abs(q_bar / se_mi))), index=q_bar.index)

# Build the comparison table
rows = []
for var in FEATURES:
    label = UNITS[var][0]
    o_cc, l_cc, h_cc = or_ci(m_cc.params[var], m_cc.bse[var])
    o_si, l_si, h_si = or_ci(m_si.params[var], m_si.bse[var])
    o_mi, l_mi, h_mi = or_ci(q_bar[var], se_mi[var])
    rows.append({
        "Predictor": f"{var} ({label})",
        "Complete case": f"{o_cc:.2f} ({l_cc:.2f}-{h_cc:.2f})",
        "Single imputation": f"{o_si:.2f} ({l_si:.2f}-{h_si:.2f})",
        "Multiple imputation": f"{o_mi:.2f} ({l_mi:.2f}-{h_mi:.2f})",
        "p (MI)": "<0.001" if p_mi[var] < 0.001 else f"{p_mi[var]:.3f}",
    })
or_table = pd.DataFrame(rows)
print(f"Rows used: complete case {len(cc)} of {len(df)}; imputed {len(df_clean)}")
print(or_table.to_string(index=False))

# Forest plot of the multiple-imputation estimates
est = [or_ci(q_bar[v], se_mi[v]) for v in FEATURES]
fig, ax = plt.subplots(figsize=(7, 4))
ypos = np.arange(len(FEATURES))[::-1]
for y_, (o, l, h) in zip(ypos, est):
    ax.plot([l, h], [y_, y_], color="black")
    ax.plot(o, y_, "s", color="tab:blue")
ax.axvline(1, linestyle="--", color="gray")
ax.set_yticks(ypos)
ax.set_yticklabels([f"{v} ({UNITS[v][0]})" for v in FEATURES])
ax.set_xlabel("Odds ratio (95% CI), multiple imputation")
ax.set_title("Adjusted odds ratios for 10-year CHD")
plt.tight_layout()
plt.show() 
```

    Rows used: complete case 3803 of 4240; imputed 4240
                             Predictor    Complete case Single imputation Multiple imputation p (MI)
                    age (per 10 years) 1.94 (1.72-2.20)  1.90 (1.69-2.14)    1.90 (1.69-2.14) <0.001
                 male (male vs female) 1.76 (1.43-2.16)  1.66 (1.36-2.01)    1.66 (1.37-2.01) <0.001
    cigsPerDay (per 10 cigarettes/day) 1.23 (1.13-1.33)  1.24 (1.15-1.33)    1.23 (1.14-1.33) <0.001
                totChol (per 10 mg/dL) 1.03 (1.01-1.05)  1.02 (1.00-1.04)    1.02 (1.00-1.04)  0.103
                   sysBP (per 10 mmHg) 1.18 (1.13-1.23)  1.18 (1.13-1.23)    1.18 (1.13-1.23) <0.001
                     BMI (per 5 kg/m2) 1.05 (0.93-1.18)  1.03 (0.92-1.15)    1.03 (0.92-1.15)  0.635
                glucose (per 10 mg/dL) 1.08 (1.05-1.12)  1.08 (1.05-1.12)    1.08 (1.04-1.11) <0.001
    


    
![png](output_5_1.png)
    



```python
from sklearn.pipeline import Pipeline
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score, cross_val_predict

FEATURES = ["age", "male", "cigsPerDay", "totChol", "sysBP", "BMI", "glucose"]

X = df[FEATURES]                 # RAW data with NaNs (not df_clean)
y = df["TenYearCHD"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

pipe = Pipeline([
    ("impute", IterativeImputer(random_state=42, max_iter=10)),
    ("scale",  StandardScaler()),
    ("clf",    LogisticRegression(C=1e6, max_iter=1000)),   # C=1e6 ~ no penalty
])

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Cross-validated AUC on the training set only
cv_auc = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="roc_auc")
print(f"CV ROC-AUC (train): {cv_auc.mean():.3f} +/- {cv_auc.std():.3f}")

# Out-of-fold predicted probabilities for every training row
oof_proba = cross_val_predict(pipe, X_train, y_train, cv=cv, method="predict_proba")[:, 1]

# Final fit on the full training set, then predict the untouched test set
pipe.fit(X_train, y_train)
test_proba = pipe.predict_proba(X_test)[:, 1]
```

    CV ROC-AUC (train): 0.732 +/- 0.031
    


```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, brier_score_loss
from sklearn.calibration import calibration_curve

auc = roc_auc_score(y_test, test_proba)

# Bootstrap 95% CI for the test AUC
rng = np.random.default_rng(42)
y_arr = np.asarray(y_test)
boot = []
for _ in range(1000):
    idx = rng.integers(0, len(y_arr), len(y_arr))
    if y_arr[idx].min() == y_arr[idx].max():
        continue
    boot.append(roc_auc_score(y_arr[idx], test_proba[idx]))
lo, hi = np.percentile(boot, [2.5, 97.5])
print(f"Test ROC-AUC: {auc:.3f}  (95% bootstrap CI {lo:.3f}-{hi:.3f})")

# Brier score vs. a model that always predicts the training prevalence
brier = brier_score_loss(y_test, test_proba)
brier_ref = brier_score_loss(y_test, np.full(len(y_test), y_train.mean()))
print(f"Brier score: {brier:.4f}  (reference, prevalence only: {brier_ref:.4f})")

# Calibration slope and intercept (ideal: slope 1, intercept 0)
eps = 1e-6
p = np.clip(test_proba, eps, 1 - eps)
logit = np.log(p / (1 - p))
cal = LogisticRegression(C=1e6, max_iter=1000).fit(logit.reshape(-1, 1), y_test)
print(f"Calibration slope: {cal.coef_[0][0]:.2f}   intercept: {cal.intercept_[0]:.2f}")

# Calibration curve
frac_pos, mean_pred = calibration_curve(y_test, test_proba, n_bins=8, strategy="quantile")
plt.figure(figsize=(6, 6))
plt.plot([0, 0.6], [0, 0.6], "--", color="gray", label="Perfect calibration")
plt.plot(mean_pred, frac_pos, "o-", label="Model")
plt.xlabel("Predicted 10-year risk")
plt.ylabel("Observed proportion with CHD")
plt.title("Calibration curve (test set)")
plt.legend()
plt.tight_layout()
plt.show() 
```

    Test ROC-AUC: 0.704  (95% bootstrap CI 0.654-0.748)
    Brier score: 0.1207  (reference, prevalence only: 0.1290)
    Calibration slope: 0.80   intercept: -0.29
    


    
![png](output_7_1.png)
    



```python
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

beta = stat_model.params            # same model that drives the calculator

# 1 point = the log-odds effect of this many years of age. Lower = finer scale, more points.
YEARS_PER_POINT = 2.5
B = beta["age"] * YEARS_PER_POINT   # log-odds per point

# Bands: internal cut points and a representative value (midpoint) for each band
BANDS = {
    "age":        {"cuts": [35, 40, 45, 50, 55, 60, 65],      "mids": [32.5, 37.5, 42.5, 47.5, 52.5, 57.5, 62.5, 67.5]},
    "male":       {"cuts": [0.5],                              "mids": [0, 1],                                          "labels": ["Female", "Male"]},
    "cigsPerDay": {"cuts": [1, 10, 20, 30],                    "mids": [0, 5, 15, 25, 35]},
    "totChol":    {"cuts": [200, 240, 280],                    "mids": [180, 220, 260, 310]},
    "sysBP":      {"cuts": [110, 120, 130, 140, 150, 160, 170],"mids": [100, 115, 125, 135, 145, 155, 165, 185]},
    "BMI":        {"cuts": [22, 25, 30, 35],                   "mids": [20, 23.5, 27.5, 32.5, 39]},
    "glucose":    {"cuts": [85, 100, 126, 200],                "mids": [75, 92, 112, 160, 260]},
}

def band_labels(spec):
    if "labels" in spec:
        return spec["labels"]
    c = spec["cuts"]
    return [f"<{c[0]}"] + [f"{c[i]} to <{c[i+1]}" for i in range(len(c) - 1)] + [f">={c[-1]}"]

# Points per band: round(beta * (band value - reference value) / B); reference = lowest-risk band
rows, point_lookup, ref_logit = [], {}, beta["const"]
for var, spec in BANDS.items():
    mids = np.array(spec["mids"], dtype=float)
    labels = band_labels(spec)
    contrib = beta[var] * mids
    ref = int(np.argmin(contrib))
    pts = np.round((contrib - contrib[ref]) / B).astype(int)
    point_lookup[var] = pts
    ref_logit += contrib[ref]
    for lab, p in zip(labels, pts):
        rows.append({"Variable": var, "Band": lab, "Points": int(p)})
points_table = pd.DataFrame(rows)
print(f"1 point = odds x {np.exp(B):.2f}  (equivalent to {YEARS_PER_POINT} years of age)\n")
print(points_table.to_string(index=False))

def score_points(d):
    """Total points for a DataFrame (or dict of scalars) containing the 7 predictors."""
    d = pd.DataFrame(d) if not isinstance(d, pd.DataFrame) else d
    total = np.zeros(len(d), dtype=int)
    for var, spec in BANDS.items():
        idx = np.digitize(d[var].to_numpy(dtype=float), spec["cuts"])
        total += point_lookup[var][idx]
    return total

def points_to_risk(total):
    return 1 / (1 + np.exp(-(ref_logit + np.asarray(total) * B)))

# Points -> risk lookup
max_total = int(sum(p.max() for p in point_lookup.values()))
lookup = pd.DataFrame({"Total points": range(0, max_total + 1, 2)})
lookup["Estimated 10-yr risk"] = (points_to_risk(lookup["Total points"]) * 100).round(1).astype(str) + "%"
print("\nPoints to risk:")
print(lookup.to_string(index=False))

# How much does simplifying to points cost? (in-sample, same data the model was fit on)
total = score_points(df_clean)
eta = beta["const"] + sum(beta[v] * df_clean[v] for v in FEATURES)
model_risk = 1 / (1 + np.exp(-eta))
score_risk = points_to_risk(total)
y_all = df_clean["TenYearCHD"].astype(int)
print(f"\nAUC, full model:  {roc_auc_score(y_all, model_risk):.3f}")
print(f"AUC, point score: {roc_auc_score(y_all, total):.3f}")
print(f"Mean risk: model {model_risk.mean():.3f}, score {score_risk.mean():.3f}, observed {y_all.mean():.3f}")

# Calibration of the score: predicted vs observed risk by score group
grp = pd.qcut(pd.Series(total), q=6, duplicates="drop")
cal = pd.DataFrame({"grp": grp, "pred": score_risk, "obs": y_all.values}).groupby("grp", observed=True).agg(
    n=("obs", "size"), mean_predicted=("pred", "mean"), observed=("obs", "mean")).round(3)
print("\nScore calibration (grouped by total points):")
print(cal.to_string())

# Worked example (same patient as the calculator test)
ex = pd.DataFrame([dict(age=65, male=1, cigsPerDay=20, totChol=280, sysBP=160, BMI=32, glucose=140)])
ex_pts = int(score_points(ex)[0])
ex_exact = 1 / (1 + np.exp(-(beta["const"] + sum(beta[v] * ex[v].iloc[0] for v in FEATURES))))
print(f"\nExample patient: {ex_pts} points -> score risk {points_to_risk(ex_pts)*100:.1f}%  "
      f"(exact model risk {ex_exact*100:.1f}%)")

from scipy.optimize import brentq
shift = brentq(lambda s: (1 / (1 + np.exp(-(ref_logit + s + total * B)))).mean() - y_all.mean(), -2, 2)
ref_logit += shift
score_risk = points_to_risk(total)
print(f"Intercept shift applied: {shift:+.3f}")
print(f"Mean risk: model {model_risk.mean():.3f}, score {score_risk.mean():.3f}, observed {y_all.mean():.3f}")
print(f"Example patient: {ex_pts} points -> {points_to_risk(ex_pts)*100:.1f}%") 
```

    1 point = odds x 1.17  (equivalent to 2.5 years of age)
    
      Variable        Band  Points
           age         <35       0
           age   35 to <40       2
           age   40 to <45       4
           age   45 to <50       6
           age   50 to <55       8
           age   55 to <60      10
           age   60 to <65      12
           age        >=65      14
          male      Female       0
          male        Male       3
    cigsPerDay          <1       0
    cigsPerDay    1 to <10       1
    cigsPerDay   10 to <20       2
    cigsPerDay   20 to <30       3
    cigsPerDay        >=30       5
       totChol        <200       0
       totChol 200 to <240       0
       totChol 240 to <280       1
       totChol       >=280       1
         sysBP        <110       0
         sysBP 110 to <120       2
         sysBP 120 to <130       3
         sysBP 130 to <140       4
         sysBP 140 to <150       5
         sysBP 150 to <160       6
         sysBP 160 to <170       7
         sysBP       >=170       9
           BMI         <22       0
           BMI   22 to <25       0
           BMI   25 to <30       0
           BMI   30 to <35       0
           BMI        >=35       1
       glucose         <85       0
       glucose  85 to <100       1
       glucose 100 to <126       2
       glucose 126 to <200       4
       glucose       >=200       9
    
    Points to risk:
     Total points Estimated 10-yr risk
                0                 1.5%
                2                 2.0%
                4                 2.8%
                6                 3.8%
                8                 5.2%
               10                 7.0%
               12                 9.4%
               14                12.5%
               16                16.4%
               18                21.3%
               20                27.2%
               22                33.9%
               24                41.5%
               26                49.4%
               28                57.4%
               30                65.0%
               32                71.9%
               34                77.9%
               36                82.9%
               38                87.0%
               40                90.2%
               42                92.7%
    
    AUC, full model:  0.730
    AUC, point score: 0.727
    Mean risk: model 0.152, score 0.160, observed 0.152
    
    Score calibration (grouped by total points):
                     n  mean_predicted  observed
    grp                                         
    (-0.001, 9.0]  905           0.045     0.041
    (9.0, 12.0]    697           0.082     0.082
    (12.0, 14.0]   598           0.117     0.107
    (14.0, 17.0]   832           0.163     0.159
    (17.0, 20.0]   609           0.239     0.245
    (20.0, 36.0]   599           0.384     0.342
    
    Example patient: 32 points -> score risk 71.9%  (exact model risk 63.5%)
    Intercept shift applied: -0.070
    Mean risk: model 0.152, score 0.152, observed 0.152
    Example patient: 32 points -> 70.4%
    


```python
from sklearn.metrics import roc_curve, confusion_matrix

fpr, tpr, thr = roc_curve(y_train, oof_proba)
best = np.argmax(tpr - fpr)                  # Youden's J
threshold = thr[best]
print(f"Chosen threshold (max Youden J on out-of-fold training predictions): {threshold:.3f}")
print(f"Cohort prevalence for reference: {y_train.mean():.3f}")

pred = (test_proba >= threshold).astype(int)
tn, fp, fn, tp = confusion_matrix(y_test, pred).ravel()

print("\nConfusion matrix (test set):")
print(confusion_matrix(y_test, pred))
print(f"Sensitivity (recall): {tp / (tp + fn):.3f}")
print(f"Specificity:          {tn / (tn + fp):.3f}")
print(f"PPV (precision):      {tp / (tp + fp):.3f}")
print(f"NPV:                  {tn / (tn + fn):.3f}")
```

    Chosen threshold (max Youden J on out-of-fold training predictions): 0.154
    Cohort prevalence for reference: 0.152
    
    Confusion matrix (test set):
    [[498 221]
     [ 49  80]]
    Sensitivity (recall): 0.620
    Specificity:          0.693
    PPV (precision):      0.266
    NPV:                  0.910
    


```python
## testing for interaction between age and systolic blood pressure
df_clean['age_x_sysBP'] = df_clean['age'] * df_clean['sysBP']

X_interaction = df_clean[['age', 'male', 'cigsPerDay', 'totChol', 'sysBP', 'BMI', 'glucose', 'age_x_sysBP']]
X_interaction_stat = sm.add_constant(X_interaction)

interaction_model = sm.Logit(df_clean['TenYearCHD'], X_interaction_stat).fit()
print(interaction_model.summary()) 
```

    Optimization terminated successfully.
             Current function value: 0.379594
             Iterations 7
                               Logit Regression Results                           
    ==============================================================================
    Dep. Variable:             TenYearCHD   No. Observations:                 4240
    Model:                          Logit   Df Residuals:                     4231
    Method:                           MLE   Df Model:                            8
    Date:                Wed, 11 Nov 2026   Pseudo R-squ.:                  0.1089
    Time:                        14:36:25   Log-Likelihood:                -1609.5
    converged:                       True   LL-Null:                       -1806.1
    Covariance Type:            nonrobust   LLR p-value:                 5.192e-80
    ===============================================================================
                      coef    std err          z      P>|z|      [0.025      0.975]
    -------------------------------------------------------------------------------
    const         -10.5664      1.850     -5.713      0.000     -14.191      -6.941
    age             0.0946      0.034      2.799      0.005       0.028       0.161
    male            0.4938      0.099      4.989      0.000       0.300       0.688
    cigsPerDay      0.0213      0.004      5.496      0.000       0.014       0.029
    totChol         0.0016      0.001      1.583      0.113      -0.000       0.004
    sysBP           0.0289      0.014      2.114      0.034       0.002       0.056
    BMI             0.0048      0.011      0.424      0.671      -0.017       0.027
    glucose         0.0077      0.002      4.730      0.000       0.005       0.011
    age_x_sysBP    -0.0002      0.000     -0.917      0.359      -0.001       0.000
    ===============================================================================
    


```python
# Calculate the ROC curve points
fpr, tpr, thresholds = roc_curve(y_test, test_proba)
auc_score = roc_auc_score(y_test, test_proba)


plt.figure(figsize=(7, 6))
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'Logistic Regression (AUC = {auc_score:.3f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random Guess (AUC = 0.500)')

plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate (1 - Sensitivity)')
plt.ylabel('True Positive Rate (Recall)')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.tight_layout()
plt.show()
```


    
![png](output_11_0.png)
    



```python
import numpy as np 

FEATURES = ["age", "male", "cigsPerDay", "totChol", "sysBP", "BMI", "glucose"]

HARD_LIMITS = {
    "age": (18, 110), "cigsPerDay": (0, 100), "totChol": (80, 700),
    "sysBP": (70, 300), "BMI": (10, 70), "glucose": (30, 600),
}

def training_ranges(df, features=FEATURES, lower=0.01, upper=0.99):
    return {f: (float(df[f].quantile(lower)), float(df[f].quantile(upper)))
            for f in features if f != "male"}

def validate_inputs(inputs, ranges=None):
    errors, warnings = [], []
    for name, (lo, hi) in HARD_LIMITS.items():
        v = inputs[name]
        if not (lo <= v <= hi):
            errors.append(f"{name}={v} is outside the plausible range {lo}-{hi}.")
    if inputs["male"] not in (0, 1):
        errors.append("male must be 0 or 1.")
    if not errors and ranges:
        for name, (lo, hi) in ranges.items():
            v = inputs[name]
            if not (lo <= v <= hi):
                warnings.append(f"{name}={v} is outside the range most common in the "
                                f"training data ({lo:.0f}-{hi:.0f}); the estimate is an extrapolation.")
    return errors, warnings

def predict_risk(model, inputs, z=1.96):
    x = np.array([1.0] + [float(inputs[f]) for f in FEATURES])
    beta = np.asarray(model.params, dtype=float)
    cov = np.asarray(model.cov_params(), dtype=float)
    eta = x @ beta
    se = float(np.sqrt(x @ cov @ x))
    sigmoid = lambda t: 1.0 / (1.0 + np.exp(-t))
    return {"risk": float(sigmoid(eta)),
            "lower": float(sigmoid(eta - z * se)),
            "upper": float(sigmoid(eta + z * se))}

def risk_band(risk):
    pct = risk * 100
    if pct < 5: return "Lower"
    if pct < 10: return "Borderline"
    if pct < 20: return "Intermediate"
    return "Higher"

def _ask_float(prompt):
    while True:
        try:
            return float(input(prompt).strip())
        except ValueError:
            print("  Please enter a number.")

def _ask_sex(prompt):
    while True:
        s = input(prompt).strip().lower()
        if s in ("male", "m"): return 1
        if s in ("female", "f"): return 0
        print("  Please enter Male or Female.")

def run_risk_calculator(model, ranges=None, baseline_prevalence=None):
    print("=" * 56)
    print("   10-YEAR CHD RISK ESTIMATOR  (educational use only)")
    print("=" * 56)
    inputs = {
        "age": _ask_float("Age (years): "),
        "male": _ask_sex("Biological sex (Male/Female): "),
        "cigsPerDay": _ask_float("Cigarettes per day (0 if none): "),
        "totChol": _ask_float("Total cholesterol (mg/dL): "),
        "sysBP": _ask_float("Systolic BP (mmHg): "),
        "BMI": _ask_float("BMI (kg/m^2): "),
        "glucose": _ask_float("Glucose (mg/dL): "),
    }
    errors, warnings = validate_inputs(inputs, ranges)
    if errors:
        print("\nCannot calculate:")
        for e in errors: print("  -", e)
        return None
    out = predict_risk(model, inputs)
    print("\n" + "-" * 56)
    print(f"Estimated 10-year CHD risk: {out['risk']*100:.1f}%")
    print(f"95% CI for this estimate:   {out['lower']*100:.1f}% - {out['upper']*100:.1f}%")
    print(f"Illustrative band:          {risk_band(out['risk'])}")
    if baseline_prevalence is not None:
        print(f"Cohort average risk:        {baseline_prevalence*100:.1f}%")
    for w in warnings: print("Warning:", w)
    print("-" * 56)
    print("This estimate comes from a statistical model fit to the Framingham")
    print("cohort. It is not a diagnosis, has not been externally validated,")
    print("and is not a substitute for clinical judgment.")
    return out
```


```python
ranges = training_ranges(df_clean)
run_risk_calculator(stat_model, ranges=ranges,
                    baseline_prevalence=df_clean['TenYearCHD'].mean())
```

    ========================================================
       10-YEAR CHD RISK ESTIMATOR  (educational use only)
    ========================================================
    

    Age (years):  60
    Biological sex (Male/Female):  Female
    Cigarettes per day (0 if none):  0
    Total cholesterol (mg/dL):  170
    Systolic BP (mmHg):  100
    BMI (kg/m^2):  22
    Glucose (mg/dL):  80
    

    
    --------------------------------------------------------
    Estimated 10-year CHD risk: 8.3%
    95% CI for this estimate:   6.4% - 10.8%
    Illustrative band:          Borderline
    Cohort average risk:        15.2%
    --------------------------------------------------------
    This estimate comes from a statistical model fit to the Framingham
    cohort. It is not a diagnosis, has not been externally validated,
    and is not a substitute for clinical judgment.
    




    {'risk': 0.08336065677384519,
     'lower': 0.06378910687528817,
     'upper': 0.1082428095112041}




```python
def calib_stats(y_true, proba):
    p = np.clip(proba, 1e-6, 1 - 1e-6)
    lg = np.log(p / (1 - p)).reshape(-1, 1)
    m = LogisticRegression(C=1e6, max_iter=1000).fit(lg, y_true)
    return m.coef_[0][0]

print(f"Mean predicted risk (test): {test_proba.mean():.3f}   observed: {np.mean(y_test):.3f}")
print(f"Mean predicted risk (OOF train): {oof_proba.mean():.3f}   observed: {np.mean(y_train):.3f}")
print(f"Calibration slope, out-of-fold train: {calib_stats(y_train, oof_proba):.2f}")

slopes = []
for _ in range(500):
    idx = rng.integers(0, len(y_arr), len(y_arr))
    if y_arr[idx].min() == y_arr[idx].max():
        continue
    slopes.append(calib_stats(y_arr[idx], test_proba[idx]))
print(f"Test calibration slope 95% CI: {np.percentile(slopes, 2.5):.2f} to {np.percentile(slopes, 97.5):.2f}")

fp_oof, mp_oof = calibration_curve(y_train, oof_proba, n_bins=10, strategy="quantile")
fp_te, mp_te = calibration_curve(y_test, test_proba, n_bins=8, strategy="quantile")
plt.figure(figsize=(6, 6))
plt.plot([0, 0.6], [0, 0.6], "--", color="gray", label="Perfect")
plt.plot(mp_oof, fp_oof, "o-", label="Train (out-of-fold)")
plt.plot(mp_te, fp_te, "s-", label="Test")
plt.xlabel("Predicted 10-year risk"); plt.ylabel("Observed proportion with CHD")
plt.title("Calibration: train (out-of-fold) vs test"); plt.legend(); plt.tight_layout(); plt.show() 
```

    Mean predicted risk (test): 0.149   observed: 0.152
    Mean predicted risk (OOF train): 0.153   observed: 0.152
    Calibration slope, out-of-fold train: 0.95
    Test calibration slope 95% CI: 0.60 to 1.01
    


    
![png](output_14_1.png)
    



```python
from sklearn.model_selection import RepeatedStratifiedKFold, cross_validate
import pandas as pd

extra1 = ["prevalentHyp", "diabetes", "BPMeds"]
feature_sets = {
    "Baseline (7)":                         FEATURES,
    "+ prevalentHyp, diabetes, BPMeds":     FEATURES + extra1,
    "+ above + diaBP":                      FEATURES + extra1 + ["diaBP"],
    "+ above + prevalentStroke, heartRate": FEATURES + extra1 + ["diaBP", "prevalentStroke", "heartRate"],
}

rcv = RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=42)   # same folds for every set
scores = {}
for name, cols in feature_sets.items():
    res = cross_validate(pipe, df.loc[X_train.index, cols], y_train, cv=rcv,
                         scoring={"auc": "roc_auc", "brier": "neg_brier_score"})
    scores[name] = {"auc": res["test_auc"], "brier": -res["test_brier"]}

base = scores["Baseline (7)"]
rows = []
for name, s in scores.items():
    d = s["auc"] - base["auc"]
    rows.append({
        "Feature set": name,
        "n features": len(feature_sets[name]),
        "CV AUC": f"{s['auc'].mean():.3f}",
        "CV Brier": f"{s['brier'].mean():.4f}",
        "AUC gain vs baseline": f"{d.mean():+.4f}",
        "Folds improved": f"{(d > 0).sum()}/{len(d)}" if name != "Baseline (7)" else "-",
    })
print(pd.DataFrame(rows).to_string(index=False))

```

                             Feature set  n features CV AUC CV Brier AUC gain vs baseline Folds improved
                            Baseline (7)           7  0.732   0.1157              +0.0000              -
        + prevalentHyp, diabetes, BPMeds          10  0.733   0.1159              +0.0009           9/15
                         + above + diaBP          11  0.732   0.1160              +0.0004           8/15
    + above + prevalentStroke, heartRate          13  0.733   0.1158              +0.0007           8/15
    


```python
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import SplineTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import RepeatedStratifiedKFold, cross_validate
import pandas as pd

# Positions of the continuous predictors within FEATURES: age, sysBP, glucose
spline_idx = [FEATURES.index(c) for c in ["age", "sysBP", "glucose"]]

spline_pipe = Pipeline([
    ("impute", IterativeImputer(random_state=42, max_iter=10)),
    ("spline", ColumnTransformer(
        [("sp", SplineTransformer(n_knots=4, degree=3, include_bias=False), spline_idx)],
        remainder="passthrough")),
    ("scale", StandardScaler()),
    ("clf",   LogisticRegression(C=1e6, max_iter=5000)),
])

# Gradient boosting handles missing values itself; kept shallow and regularized on purpose
gb_pipe = HistGradientBoostingClassifier(
    max_depth=3, learning_rate=0.05, max_iter=200,
    min_samples_leaf=50, l2_regularization=1.0, random_state=42)

models = {
    "Logistic, linear (baseline)": pipe,
    "Logistic + splines (age, sysBP, glucose)": spline_pipe,
    "Gradient boosting (shallow)": gb_pipe,
}

rcv = RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=42)   # same folds as before
scores = {}
for name, model in models.items():
    res = cross_validate(model, X_train, y_train, cv=rcv,
                         scoring={"auc": "roc_auc", "brier": "neg_brier_score"})
    scores[name] = {"auc": res["test_auc"], "brier": -res["test_brier"]}

base = scores["Logistic, linear (baseline)"]
rows = []
for name, s in scores.items():
    d = s["auc"] - base["auc"]
    rows.append({
        "Model": name,
        "CV AUC": f"{s['auc'].mean():.3f}",
        "CV Brier": f"{s['brier'].mean():.4f}",
        "AUC gain vs baseline": f"{d.mean():+.4f}",
        "Folds improved": f"{(d > 0).sum()}/{len(d)}" if "baseline" not in name else "-",
    })
print(pd.DataFrame(rows).to_string(index=False))
```

                                       Model CV AUC CV Brier AUC gain vs baseline Folds improved
                 Logistic, linear (baseline)  0.732   0.1157              +0.0000              -
    Logistic + splines (age, sysBP, glucose)  0.733   0.1166              +0.0009           8/15
                 Gradient boosting (shallow)  0.720   0.1173              -0.0118           1/15
    


```python

```
